/* triangle.h */



#ifndef TRIANGLE_H
#define TRIANGLE_H

#include "GL/gl.h"


extern void gl_triangle4( GLuint v0, GLuint v1, GLuint v2, GLuint pv );

extern void gl_triangle5( GLuint v0, GLuint v1, GLuint v2, GLuint pv );

extern void gl_color_triangle5( GLuint v0, GLuint v1, GLuint v2, GLuint pv );


#endif
