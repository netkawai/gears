/* dd.h */

/*
 * Mesa 3-D graphics library
 * Version:  1.2
 * Copyright (C) 1995  Brian Paul  (brianp@ssec.wisc.edu)
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Library General Public
 * License as published by the Free Software Foundation; either
 * version 2 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Library General Public License for more details.
 *
 * You should have received a copy of the GNU Library General Public
 * License along with this library; if not, write to the Free
 * Software Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 */


/*
$Id: dd.h,v 1.16 1995/09/21 14:07:55 brianp Exp $

$Log: dd.h,v $
 * Revision 1.16  1995/09/21  14:07:55  brianp
 * more new DD prototyping
 *
 * Revision 1.15  1995/09/20  18:19:58  brianp
 * prototype device driver changes described
 *
 * Revision 1.14  1995/09/15  18:46:39  brianp
 * new functions pointers for all device driver functions
 *
 * Revision 1.13  1995/07/24  18:55:20  brianp
 * added dd_finish()
 *
 * Revision 1.12  1995/06/12  15:38:23  brianp
 * changed color arrays to GLubyte
 *
 * Revision 1.11  1995/05/22  20:59:34  brianp
 * Release 1.2
 *
 * Revision 1.10  1995/04/12  15:37:05  brianp
 * removed dd_draw_pixel(), dd_draw_line(), and dd_draw_polygon()
 *
 * Revision 1.9  1995/04/11  14:04:57  brianp
 * introduced DD struct of function pointers
 *
 * Revision 1.8  1995/03/30  21:07:49  brianp
 * updated to use pointers to CC.write_* functions
 *
 * Revision 1.7  1995/03/22  21:36:53  brianp
 * removed mode from dd_buffer_info()
 *
 * Revision 1.6  1995/03/08  15:10:02  brianp
 * added support for dd_logicop
 * added dd_clear_index and dd_clear_color
 *
 * Revision 1.5  1995/03/07  19:01:39  brianp
 * added dd_read_index_pixels() and dd_read_color_pixels()
 *
 * Revision 1.4  1995/03/07  14:20:41  brianp
 * updated for new XSetForeground/GC scheme
 *
 * Revision 1.3  1995/03/04  19:25:29  brianp
 * 1.1 beta revision
 *
 * Revision 1.2  1995/02/27  22:48:36  brianp
 * modified for PB
 *
 * Revision 1.1  1995/02/24  14:20:25  brianp
 * Initial revision
 *
 */


#ifndef DD_INCLUDED
#define DD_INCLUDED


#include "GL/gl.h"


/*
 * CHANGES COMING UP...
 *
 * The NEW_DD symbol denotes changes which will be made after Mesa 1.2.3.
 * At that time, all device drivers will have to be updated:
 *    1. all dd_xxx calls will be replaced by (*DD.xxx) calls
 *    2. the DD.read_buffer() and DD.draw_buffer() functions will only
 *       have to accept GL_FRONT and GL_BACK, and return nothing.
 *    3. the get_points|line|polygons_func functions will have to be
 *       implemented, or at least return NULL.
 *    4. remove the DD.draw_point, DD.draw_line, and DD.draw_polygon
 *       functions since item 3 will replace their functionality.
 *    5. The write_color_span function will have to accept NULL as its
 *       mask which will indicate "draw all pixels".
 *    6. the quikpoly.c file will probably be eliminated
 */

/*#define NEW_DD*/



/*
 *                      Device Driver (DD) interface
 *
 *
 * All device driver functions are accessed via pointers in the global
 * DD struct.  The pointers in this struct must be initialized by the
 * Mesa/window system interface (xmesa.c for example).
 *
 * Many of the pointers can be initialized once then forgotten.  Others
 * may have to be reassigned depending on the frame buffer configuration.
 *
 * For example, in the X/Mesa driver there are many pixel span writing
 * functions, each optimized for a specific visual or pixmap/ximage config-
 * uration.  These function pointers have to be updated whenever the
 * glDrawBuffer() function is called.
 *
 * The reason we use function pointers is to:
 *   1. allow switching between a number of different device drivers at
 *      runtime.
 *   2. use optimized functions dependend on frame buffer configuration
 *
 * 
 * Here's a quick description of each function pointer's purpose:
 *
 * buffer_info - return width, height, depth of image buffer
 * finish - implements glFinish()
 * flush - implements glFlush()
#ifdef NEW_DD
 * read_buffer - set span/pixel read source to GL_FRONT or GL_BACK
 * draw_buffer - set span/pixel draw destination to GL_FRONT or GL_BACK
 *   NEW: only have to accept GL_FRONT or GL_BACK
#else
 * read_buffer - implements glReadBuffer(), return GL_TRUE/FALSE for success
 * draw_buffer - implements glDrawBuffer(), return GL_TRUE/FALSE for success
#endif
 * clear_index - implements glClearIndex()
 * clear_color - implements glClearColor()
 * clear - implements glClear(), with some special arguments
 * index - implements glIndex()
 * index_mask - implements glIndexMask()
 * color - implements glColor()
 * color_mask - implements glColorMask()
 * logicop - implements glLogicOp() if possible, else return GL_FALSE
 *
 *
 * These functions provide the interface to "accelerated" rendering.  Each
 * function should return a pointer to an accelerated point, line, or
 * polygon function if one exists, otherwise return NULL.  When one of these
 * functions is called, the device driver must analyze the current GL state
 * to determine if it can draw an accelerated primitive.
 * 
#ifdef NEW_DD
 * get_points_func - return pointer to a point drawing function or NULL.
 * get_lines_func - return pointer to a line drawing function or NULL.
 * get_polygon_func - return pointer to a polygon drawing function or NULL.
#else
 * draw_point - render a single pixel
 * draw_line - render a simple line segment
 * draw_polygon - render a simple flat-shaded polygon
#endif
 *
 * write_color_span - write a horizontal run of RGBA pixels
 * write_monocolor_span - write a horizontal run of mono-RGBA pixels
 * write_color_pixels - write a random array of RGBA pixels
 * write_monocolor_pixels - write a random array of mono-RGBA pixels
 *
 * write_index_span - write a horizontal run of CI pixels
 * write_nonoindex_span - write a horizontal run of mono-CI pixels
 * write_index_pixels - write a random array of CI pixels
 * write_monoindex_pixels - write a random array of mono-CI pixels
 *
 * read_index_span - read a horizontal run of color index pixels
 * read_color_span - read a horizontal run of RGBA pixels
 * read_index_pixels - read a random array of CI pixels
 * read_color_pixels - read a random array of RGBA pixels
 *
 * NOTES:
 *   RGBA = red/green/blue/alpha
 *   CI = color index (color mapped mode)
 *   mono = all pixels have the same color or index
 *
 *   The write_ functions all take an array of mask flags which indicate
 *   whether or not the pixel should be written.  One special case exists
 *   in the write_color_span function: if the mask array is NULL, then
 *   draw all pixels.  This is an optimization used for glDrawPixels().
 *
 * IN ALL CASES:
 *      X coordinates start at 0 at the left and increase to the right
 *      Y coordinates start at 0 at the bottom and increase upward
 */





#ifdef NEW_DD
typedef void (*points_func)( GLuint first, GLuint last );
typedef void (*line_func)( GLuint v1, GLuint v2, GLuint pv );
typedef void (*polygon_func)( GLuint n, GLuint vlist[], GLuint pv );
#endif



struct dd_function_table {

   /*
    * Functions for implementing basic GL operations:
    */
   void (*buffer_info)( GLuint *width, GLuint *height, GLuint *depth );

   void (*finish)( void );
   void (*flush)( void );

#ifdef NEW_DD
   void (*read_buffer)( GLenum mode );
   void (*draw_buffer)( GLenum mode );
#else
   GLenum (*read_buffer)( GLenum mode );
   GLenum (*draw_buffer)( GLenum mode );
#endif

   void (*clear_index)( GLuint index );
   void (*clear_color)( const GLfloat color[4] );
   void (*clear)( GLboolean all, GLint x, GLint y, GLint width, GLint height );

   void (*index)( GLuint index );
   void (*index_mask)( GLuint mask );
   void (*color)( const GLfloat color[4] );
   void (*color_mask)( GLboolean rmask, GLboolean gmask,
                       GLboolean bmask, GLboolean amask );

   GLboolean (*logicop)( GLenum op );

   /*
    * Return pointers to accelerated rendering functions:
    */
#ifdef NEW_DD
   points_func (*get_points_func)( void );
   line_func (*get_line_func)( void );
   polygon_func (*get_polygon_func)( void );

   void (*draw_pixel)( GLint x, GLint y );  /* temporary*/
   void (*draw_line)( GLint x0, GLint y0, GLint x1, GLint y1 );/*temporary*/
   void (*draw_polygon)( GLuint n, GLint x[], GLint y[] );/*temporary*/

#else
   /*
    * Functions for simple points, line segments and polygons:
    */
   void (*draw_pixel)( GLint x, GLint y );
   void (*draw_line)( GLint x0, GLint y0, GLint x1, GLint y1 );
   void (*draw_polygon)( GLuint n, GLint x[], GLint y[] );
   /*void (*draw_flat_z_polygon)( GLuint n, GLuint vlist[], GLuint pv );*/
#endif

   /*
    * Functions for writing pixels to the frame buffer:
    */
   void (*write_color_span)( GLuint n, GLint x, GLint y,
			     const GLubyte red[], const GLubyte green[],
			     const GLubyte blue[], const GLubyte alpha[],
			     const GLubyte mask[] );
   void (*write_monocolor_span)( GLuint n, GLint x, GLint y,
				 const GLubyte mask[] );
   void (*write_color_pixels)( GLuint n, const GLint x[], const GLint y[],
			       const GLubyte red[], const GLubyte green[],
			       const GLubyte blue[], const GLubyte alpha[],
			       const GLubyte mask[] );
   void (*write_monocolor_pixels)( GLuint n, const GLint x[], const GLint y[],
				   const GLubyte mask[] );
   void (*write_index_span)( GLuint n, GLint x, GLint y, const GLuint index[],
			     const GLubyte mask[] );
   void (*write_monoindex_span)( GLuint n, GLint x, GLint y,
				 const GLubyte mask[] );
   void (*write_index_pixels)( GLuint n, const GLint x[], const GLint y[],
			       const GLuint index[], const GLubyte mask[] );
   void (*write_monoindex_pixels)( GLuint n, const GLint x[], const GLint y[],
				   const GLubyte mask[] );

   /*
    * Functions to read pixels from frame buffer:
    */
   void (*read_index_span)( GLuint n, GLint x, GLint y, GLuint index[] );
   void (*read_color_span)( GLuint n, GLint x, GLint y,
			    GLubyte red[], GLubyte green[],
			    GLubyte blue[], GLubyte alpha[] );
   void (*read_index_pixels)( GLuint n, const GLint x[], const GLint y[],
			      GLuint indx[] );
   void (*read_color_pixels)( GLuint n, const GLint x[], const GLint y[],
			      GLubyte red[], GLubyte green[],
			      GLubyte blue[], GLubyte alpha[] );

};



extern struct dd_function_table DD;




/**** OBSOLETE!!!!! *****/      /**** OBSOLETE!!!!! *****/
/**** OBSOLETE!!!!! *****/      /**** OBSOLETE!!!!! *****/
/**** These functions will be removed in a future version of Mesa ****/
/**** in favor of the function pointers in the above struct!!!!   ****/


/* Implements glFinish() */
extern void dd_finish( void );


/* Implements glFlush() */
extern void dd_flush( void );


/* Return characteristics of the output buffer. */
extern void dd_buffer_info( GLuint *width, GLuint *height, GLuint *depth );



/*
 * Specify which buffer to read from.
 * Input:  mode - as passed to glReadBuffer
 * Return:  new mode or GL_FALSE if error.
 */
#ifdef NEW_DD
extern void dd_read_buffer( GLenum mode );
#else
extern GLenum dd_read_buffer( GLenum mode );
#endif

/*
 * Specify which buffer(s) to draw into.
 * Input:  mode - as passed to glDrawBuffer
 * Return:  new output mode or GL_FALSE if error.
 */
#ifdef NEW_DD
extern void dd_draw_buffer( GLenum mode );
#else
extern GLenum dd_draw_buffer( GLenum mode );
#endif


/*
 * Set the color index used to clear the color buffer.
 * This implements glClearIndex().
 */
extern void dd_clear_index( GLuint index );



/*
 * Set the color used to clear the color buffer.
 * This implements glClearColor().
 */
extern void dd_clear_color( const GLfloat color[4] );



/*
 * Clear the color buffer using the clear color or index as specified
 * by one of the two functions above.
 */
extern void dd_clear( GLboolean all, GLint x, GLint y, GLint width, GLint height );



/*
 * Set the pixel logic operation.  Return GL_TRUE if the device driver
 * can perform the operation, otherwise return GL_FALSE.  If GL_FALSE
 * is returned, the logic op will be done in software by Mesa.
 */
extern GLboolean dd_logicop( GLenum op );


/* Set the current color index. */
extern void dd_index( GLuint index );


/* Set the index mode bitplane mask. */
extern void dd_index_mask( GLuint mask );


/* Set the current RGBA color. */
extern void dd_color( const GLfloat color[4] );


/* Set the RGBA drawing mask. */
extern void dd_color_mask( GLboolean rmask, GLboolean gmask,
			   GLboolean bmask, GLboolean amask );




#endif

