/* bresenhm.h */

/*
 * Mesa 3-D graphics library
 * Version:  1.2
 * Copyright (C) 1995  Brian Paul  (brianp@ssec.wisc.edu)
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Library General Public
 * License as published by the Free Software Foundation; either
 * version 2 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Library General Public License for more details.
 *
 * You should have received a copy of the GNU Library General Public
 * License along with this library; if not, write to the Free
 * Software Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 */


/*
$Id: bresenhm.h,v 1.4 1995/06/09 17:45:58 brianp Exp $

$Log: bresenhm.h,v $
 * Revision 1.4  1995/06/09  17:45:58  brianp
 * renamed to bresenhm.[ch]
 *
 * Revision 1.3  1995/05/22  20:59:34  brianp
 * Release 1.2
 *
 * Revision 1.2  1995/03/04  19:25:29  brianp
 * 1.1 beta revision
 *
 * Revision 1.1  1995/02/24  14:18:07  brianp
 * Initial revision
 *
 */


/*
 * A macro which executes Bresenham's line drawing algorithm.  The
 * previously defined BRESENHAM_PLOT macro is then used to 'plot' pixels.
 */


#ifndef BRESENHAM_H
#define BRESENHAM_H


#include "GL/gl.h"



#define BRESENHAM( x1, y1, x2, y2 )	\
{					\
   GLint dx, dy, xf, yf, a, b, t, i;	\
   if (x1!=x2 || y1!=y2) {		\
      if (x2>x1) {			\
         dx = x2-x1;			\
         xf = 1;			\
      }					\
      else {				\
         dx = x1-x2;			\
         xf = -1;			\
      }					\
      if (y2>y1) {			\
         dy = y2-y1;			\
         yf = 1;			\
      }					\
      else {				\
         dy = y1-y2;			\
         yf = -1;			\
      }					\
      if (dx>dy) {			\
         a = dy+dy;			\
         t = a-dx;			\
         b = t-dx;			\
         for (i=0;i<=dx;i++) {		\
	    BRESENHAM_PLOT( x1, y1 )	\
            x1 += xf;			\
            if (t<0) {			\
               t += a;			\
            }				\
            else {			\
               t += b;			\
               y1 += yf;		\
            }				\
         }				\
      }					\
      else {				\
         a = dx+dx;			\
         t = a-dy;			\
         b = t-dy;			\
         for (i=0;i<=dy;i++) {		\
	    BRESENHAM_PLOT( x1, y1 )	\
            y1 += yf;			\
            if (t<0) {			\
               t += a;			\
            }				\
            else {			\
               t += b;			\
               x1 += xf;		\
	    }				\
         }				\
      }					\
   }					\
}



extern GLuint gl_bresenham( GLint x1, GLint y1, GLint x2, GLint y2,
			    GLint x[], GLint y[] );


extern GLuint gl_stippled_bresenham( GLint x1, GLint y1, GLint x2, GLint y2,
				     GLint x[], GLint y[], GLubyte mask[] );



#endif
